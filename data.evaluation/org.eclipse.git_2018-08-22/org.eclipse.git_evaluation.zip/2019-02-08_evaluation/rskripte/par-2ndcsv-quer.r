#Import von noetigen Bibliotheken
library(ggplot2)
library(scales)
library(ggthemr)
library("tikzDevice")

#Import der CSV-Datei
md <- read.csv(file="rq3-4_hor.csv", header=TRUE, sep=";")

#Headerumbenennung
header <- c("Project","Avg.Elements","Inconsistency","Context Element","Time.ms.Load.Calculate.Revision","Time.ms.Recognition.Time","Time.ms.Complement.Matching","Complements.Repairs","Historically Observable Repairs (HOR)","Historically Observable Undos (HOU)","Ranking.of.Best.HOR")
names(md) <- header

md$Ranking.of.Best.HOR <- ifelse(md$Ranking.of.Best.HOR == 0,1,2)

#Projektliste
projects <- c("atl","birt","bpmn2","buckminster","cbi","e4","eavp","edapt","emf","gmf-tooling","ocl","papyrus","qvtd","sirius","stem","uml2")

#Projektliste für Iteration
proit <- c("atl","birt","bpmn2","buckminster","cbi","e4","eavp","edapt","emf","gmf","ocl","papyrus","qvtd","sirius","stem","uml2")

#Filtern der Daten nach Projekt
atl <- md[which(md$Project=="atl"),]
birt <- md[which(md$Project=="birt"),]
bpmn2 <- md[which(md$Project=="bpmn2"),]
buckminster <- md[which(md$Project=="buckminster"),]
cbi <- md[which(md$Project=="cbi"),]
e4 <- md[which(md$Project=="e4"),]
eavp <- md[which(md$Project=="eavp"),]
edapt <- md[which(md$Project=="edapt"),]
emf <- md[which(md$Project=="emf"),]
gmf <- md[which(md$Project=="gmf-tooling"),]
ocl <- md[which(md$Project=="ocl"),]
papyrus <- md[which(md$Project=="papyrus"),]
# qvt <- md[which(md$Project=="qvt-oml"),]
qvtd <- md[which(md$Project=="qvtd"),]
sirius <- md[which(md$Project=="sirius"),]
stem <- md[which(md$Project=="stem"),]
uml2 <- md[which(md$Project=="uml2"),]

#Latex Tikz
tikz(file = "par-2ndcsv-quer.tex", width = 5, height = 5, sanitize=TRUE, standAlone=TRUE)

#Farbschema
ggthemr('greyscale')

#Aufbau des Plots

p <- ggplot(md, aes(x=Project,y=Avg.Elements,group=1))
p <- p + theme(axis.title = element_text(size=9),axis.text=element_text(size=7),axis.text.x=element_text(angle=90,hjust=1),legend.text=element_text(size=7),legend.title=element_text(size=9))

#Aufbau des Plots: Ranking und Repairs
for(pro_name in proit){
    pro <- eval(parse(text=pro_name))
    p <- p + geom_boxplot(data=pro,aes(x=Project,y=Complements.Repairs,fill="# Repair Alternatives"),position=position_nudge(-0.3),width=.18,outlier.size=0.2)
    p <- p + geom_point(data=pro,aes(x=Project,y=Ranking.of.Best.HOR,color="Ranking"),shape=5)
}

#Einfuegen der Achsenbeschriftungen
p <- p + scale_y_log10("# Repair Alternatives, Ranking",breaks = trans_breaks("log10", function(x) 10^x),labels = trans_format("log10", math_format(10^.x)))

p <- p + scale_x_discrete(limits=projects)


#Ändern der Richtung des Plots
# p <- p + coord_flip()


p <- p + labs(fill="Legend", color="")




#Tikz off
print(p)
dev.off()
